
# Note
Found an error in the code did not raise to power of exponent! (Credit: aymanemoc1@gmail.com)

# probabilistic-neural-network-in-python
This folder contains the simple implementation of probabilistic neural network in python.
video explanition : https://www.youtube.com/playlist?list=PLz3iwtnWFin_i4-YQvMavIfmyqxmSTKgx

## Getting Started

To run the code please use python 2.7 and run the code.
python simple_pnn_python.py or python multiple_pnn_python.py

## Acknowledgments

Inspired by Information Security Researcher, Sarah Asiri. 
Please visit her site for more of her work: http://sarahasiri.org/

### Prerequisites

Python 2.7

## Built With
Python 2.7

## More information

Please visit https://www.youtube.com/watch?v=uAKu4g7lBxU&t=1s for another video 
or https://pdfs.semanticscholar.org/b6ca/7474bd7cbedd9a3e7a43db3633794102a3ff.pdf for the theory.

## Authors

Jae Duk Seo : http://jaedukseo.com/

See also the list of [contributors](https://github.com/your/project/contributors) who participated in this project.

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

